﻿namespace $safeprojectname$;

public interface IDt
{
    #region Properties

    public DateTime CrDt { get; set; }

    public DateTime? UpDt { get; set; }

    #endregion
}