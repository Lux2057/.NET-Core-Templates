﻿namespace $safeprojectname$.Pages;

#region << Using >>

using JetBrains.Annotations;
using Microsoft.AspNetCore.Components;

#endregion

[Route(UiRoutes.About)]
[UsedImplicitly]
public partial class AboutPage : PageBase { }