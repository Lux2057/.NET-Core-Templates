﻿namespace $safeprojectname$;

public interface ILoadingStatus
{
    #region Properties

    public bool IsLoading { get; }

    #endregion
}