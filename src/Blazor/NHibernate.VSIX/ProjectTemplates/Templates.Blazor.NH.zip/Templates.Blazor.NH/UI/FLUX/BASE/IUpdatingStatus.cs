﻿namespace $safeprojectname$;

public interface IUpdatingStatus
{
    #region Properties

    public bool IsUpdating { get; }

    #endregion
}